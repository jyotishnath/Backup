<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/css/bootstrap.css" rel="stylesheet"/>
<link href="css/custom.css" rel="stylesheet"/>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/material.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet"/>
<link href="js/material/bower_components/bootstrap-select/dist/css/bootstrap-select.css" rel="stylesheet">
<script src="js/modernizr.js"></script>
<title>MyDaytoParty | Contact</title>
<link rel="icon" href="img/favicon.png" type="image/png">
</head>

<body data-hijacking="off" data-animation="scaleDown">
<section class="cd-section visible vs">
  <div class="cd_height contact">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container"> 
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          <a class="navbar-brand" href="index.php"><img src="img/logo.png"/></a> </div>
  
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="video.php">Post Videos</a></li>
            <li><a href="photo.php">Post Photos</a></li>
            <li class="lst"><a href="#"><span aria-hidden="true" class="glyphicon glyphicon-search"></span></a></li>
          </ul>
        </div>
      </div>
    </nav>
  </div>
</section>

<!-- header end -->

<section class="cd-section">
  <div class="cd_height contact-bg text-center">
    <h1 class="text-center">CONTACT</h1>
    <h4 class="sub-heading">We'd <i class="fa fa-heart-o" aria-hidden="true"></i> to help!</h4>
    <p class="heding-des">We like to create things with fun, open-minded people. Feel free to say hello!</p>
    <div class="container section-h">
    	<div class="row">
    		<div class="col-md-12">
    			<div class="col-md-6">
    				<div class="col-md-12 contact-form">
    					<form>
    						<div class="col-md-6">
    							<input type="text" name="f_name" id="f_name" class="form-control txt_box" placeholder="First Name">
    						</div>
    						<div class="col-md-6">
    							<input type="text" name="l_name" id="l_name" class="form-control txt_box" placeholder="Last Name">
    						</div>
    						<div class="col-md-6">
    							<input type="text" name="email" id="email" class="form-control txt_box" placeholder="Email">
    						</div>
    						<div class="col-md-6">
    							<input type="text" name="tel" id="tel" class="form-control txt_box" placeholder="Telephone Number">
    						</div>
    						<textarea name="message" id="message" placeholder="Message" class="form-control txt-area"></textarea>
    						<button	type="submit" class="btn btn-submit">Submit</button>
    					</form>
    				</div>
    			</div>
    			<div class="col-md-6">
    				<ul class="contact-info">
    					<li>
    						<i class="fa fa-map-marker" aria-hidden="true"></i><br/>
							<span class="address">My Day to Party</span><br/>
							<span class="address-1">Street Address, Country, Zip,</span> 
    					</li>
    					<li>
    						<i class="fa fa-phone" aria-hidden="true"></i><br/>
    						<span class="phone">(012) 345 - 6789</span>
    					</li>
    					<li>
    						<i class="fa fa-envelope-o" aria-hidden="true"></i><br/>
    						<a href="mailto:info@domain.com" class="email-address">info@domain.com</a>
    					</li>
    				</ul>
    				<hr>
    				<ul class="social-media">
    					<li><a href="javascript:void(0);"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
    					<li><a href="javascript:void(0);"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
    					<li><a href="javascript:void(0);"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
    					<li><a href="javascript:void(0);"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
    					<li><a href="javascript:void(0);"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
    				</ul>
    			</div>
    		</div>
    	</div>
    </div>
  </div>
</section>

<!-- Footer -->
<?php include('footer.php') ?>