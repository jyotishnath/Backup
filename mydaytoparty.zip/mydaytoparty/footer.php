<section class="cd-section">
   <div class="cd_height text-center" style="padding:0;">
   <div class="bg" style="background:#A5A5A5; padding:3.5em 0 2em 0; border-top:3px solid #777;">
   <div class="container">
        <div class="col-md-15 col-sm-3">
           <img src="img/1.png" class="img-responsive"/>
       </div>
       <div class="col-md-15 col-sm-3">
          <img src="img/2.png" class="img-responsive"/>
       </div>
       <div class="col-md-15 col-sm-3">
          <img src="img/3.png" class="img-responsive"/>
       </div>
       <div class="col-md-15 col-sm-3">
          <img src="img/4.png" class="img-responsive"/>
       </div>
       <div class="col-md-15 col-sm-3">
          <img src="img/5.png" class="img-responsive"/>
       </div>
   </div>
   </div>
  <div class="col-sm-12" style="padding:3em 0; position:relative;">
   <div class="container">
         <p class="sec_heading schd2" style="color:#E81E4E; margin-top:1.8em;">Join Us on Social Network</p>
        <div class="col-sm-6 col-sm-push-3"> 
         <ul class="list-inline" style="margin-top:2em;">
            <li><a href="#"><img src="img/face.png"/></a></li>
            <li><a href="#"><img src="img/twitter.png"/></a></li>
            <li><a href="#"><img src="img/intra.png"/></a></li>
            <li><a href="#"><img src="img/you.png"/></a></li>
         </ul>
         </div>
         <div class="col-sm-2 pull-right">
            <img src="img/gift.png" class="img-responsive"/>
         </div>
    </div>
    <img src="img/ring2.png" style="position:absolute; top:0; left:0; width:31%;"/>
   </div>
   
   
   <div class="col-sm-12 ftr" style="padding:1em 0; background:#D4314C; position:absolute; bottom:0; left:0; right:0;">
   <div class="row">
   <div class="container">
       <ul class="list-inline" style="margin:0;">
         <li style="border-right:1px solid #fff;">Copyright All Right Reserved &copy; 2016</li>
         <li>Designed by <a style="color:#fff;" href="http://www.goigi.com/" target="_blank">GOIGI.COM</a></li>
       </ul>
    </div>
   </div>
   </div>
  </div>
</section>
<script src="js/material/bower_components/jquery/dist/jquery.min.js"></script> 
<script src="assets/js/bootstrap.js"></script> 
<script src="js/material/bower_components/bootstrap-select/dist/js/bootstrap-select.js"></script> 
<script src="js/velocity.min.js"></script> 
<script src="js/velocity.ui.min.js"></script> 
<script src="js/main.js"></script>
<script src="js/videojs-ie8.min.js"></script>
<script src="js/video.js"></script>
<script src="js/lightbox-plus-jquery.min.js"></script>
</body>
</html>