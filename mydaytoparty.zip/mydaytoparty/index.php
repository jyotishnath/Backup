<?php include('header.php'); ?>

<section class="cd-section">
  <div class="cd_height text-center">
    <div class="col-sm-10 col-sm-push-1"> <img src="img/t1.png" style="width:60px; margin:0 auto">
      <p class="sec_heading">Check Your Day of Week</p>
      <p class="sub-title">You should know what the day was when you were born!
        Why? Because that is your real birthday!
        If your’e like most, you won’t even know what that day was!
        So, wer’e going to show you</p>
      <hr class="red-line">
      <p class="sub2">Fill in the blanks and see your day!</p>
      <p class="born">I was born</p>
      <div class="row">
        <form>
          <div class="col-sm-6 col-sm-push-3">
            <div class="col-sm-4 m-b-25">
              <select class="selectpicker">
                <option>september</option>
                <option>october</option>
                <option>november</option>
                <option>December</option>
              </select>
            </div>
            <div class="col-sm-4 m-b-25">
              <select class="selectpicker">
                <option>28</option>
                <option>29</option>
                <option>30</option>
              </select>
            </div>
            <div class="col-sm-4 m-b-25">
              <select class="selectpicker">
                <option>1989</option>
                <option>1990</option>
                <option>1991</option>
              </select>
            </div>
          </div>
        </form>
      </div>
      <p class="show-day">So, your Birthday in every <span>thursday</span></p>
      <div class="media">
        <div class="media-left"> <a href="#"> <img alt="64x64" class="media-object" style="width: 64px; height: 50px;" src="img/lolipop.png"> </a> </div>
        <div class="media-body"> So, my day is: <span>May 31 2016</span> and our 100 year calendar shows that this date falls on a friday.Now you know that your special birthday is every friday and we have sponsors who will help you celebrate every week! <span>Tuesday</span> </div>
      </div>
    </div>
  
    <img src="img/ring.png" style="position:absolute; right:0; top:0; width:30%;"/>
  </div>
</section>
<section class="cd-section">
  <div class="cd_height text-center">
    <div class="row">
      <div class="col-sm-10 col-sm-push-1"> <img src="img/sec2.png" style="width:90px; margin:0 auto;">
        <p style="color:#333; margin-top:1em; margin-bottom:0;"><small style="font-size:16px;">Get Your Free Membership in Our</small></p>
        <p class="sec_heading schd2" style="color:#E81E4E;">Its My Birthday Club</p>
        <hr style="border-color:#666;" class="red-line">
        <p class="sub-title" style="color:#333; ">Receive free promotional offers every week directly from our participating sponsors in your local area! Our sponsors will honor you birthday club card and help you celebrate your big day every week!</p>
      </div>
    </div>
   <div class="col-sm-12"> 
    <div class="row we" style="background:#f9f9f9; overflow:hidden; padding:2em 0; position:relative;">
      <div class="col-sm-10 col-sm-push-1"> <img src="img/sec3.png" style="width:300px; margin:0 auto;">
        <p style="color:#333; margin-top:1em; margin-bottom:0;"><small style="font-size:16px;">Sign up for free gifts and promotions from our sponsors</small></p>
       <div class="col-sm-10 col-sm-push-1"> 
        <form class="indx-fm">
          <div class="col-sm-4">
            <div class="input-group"> <span class="input-group-addon"><i class="zmdi zmdi-mail-send"></i></span>
              <div class="fg-line">
                <input type="email" class="form-control" placeholder="Enter your email address">
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="input-group"> <span class="input-group-addon"><i class="zmdi zmdi-mail-send"></i></span>
              <div class="fg-line">
                <input type="email" class="form-control" placeholder="Renter your email address">
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="input-group"> <span class="input-group-addon"><i class="zmdi zmdi-phone-msg zmdi-hc-fw"></i></span>
              <div class="fg-line">
                <input type="text" class="form-control" placeholder="My Phone for text Messages">
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="input-group"> <span class="input-group-addon"><i class="zmdi zmdi-flag zmdi-hc-fw"></i></span>
              <div class="fg-line">
                <input type="text" class="form-control" placeholder="My Country">
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="input-group"> <span class="input-group-addon"><i class="zmdi zmdi-my-location"></i></span>
              <div class="fg-line">
                <input type="text" class="form-control" placeholder="Zipcode or Area Code">
              </div>
            </div>
          </div>
          <div class="col-sm-4 text-right">
             <button style="width:84%; background:#EC1E50;" class="btn bgm-pink waves-effect">Sign Up</button>
          </div>
        </form>
        </div>
      </div>
      
      <img src="img/balon.png" style="  position: absolute;
    right: 20px;
    top: 68px;
    width: 8%;"/>
      </div>
    </div>
  </div>
</section>

<?php include('footer.php'); ?>