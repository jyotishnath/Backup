//$(window).load(function(){
//    function notify(message, type){
//        $.growl({
//            message: message
//        },{
//            type: type,
//            allow_dismiss: false,
//            label: 'Cancel',
//            className: 'btn-xs btn-inverse',
//            placement: {
//                from: 'top',
//                align: 'right'
//            },
//            delay: 5000,
//            animate: {
//                    enter: 'animated zoomInLeft',
//                    exit: 'animated zoomInLeft'
//            },
//            offset: {
//                x: 20,
//                y: 85
//            }
//        });
//    };
//    
//    if (!$('.login-content')[0]) {
//        notify('Welcome back Member Name', 'inverse');
//    } 
//});