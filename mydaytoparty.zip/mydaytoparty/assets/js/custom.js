 $(function(){
  var ink, d, x, y;
  $(".col").click(function(e){
    if($(this).find(".ink").length === 0){
      $(this).prepend("<span class='ink'></span>");
    }
         
    ink = $(this).find(".ink");
    ink.removeClass("animate");
     
    if(!ink.height() && !ink.width()){
      d = Math.max($(this).outerWidth(), $(this).outerHeight());
      ink.css({height: d, width: d});
    }
     
    x = e.pageX - $(this).offset().left - ink.width()/2;
    y = e.pageY - $(this).offset().top - ink.height()/2;
     
    ink.css({top: y+'px', left: x+'px'}).addClass("animate");
});
});



   var owl = $('.owl-carousel');
   owl.owlCarousel({
    items:4,
	itemsTabletSmall: [480,1],
	itemsMobile : [370,1],
    loop:true,
    margin:10,
    autoplay:true,
    autoplayTimeout:5000,
});

$(document).ready(

  function() { 

    $("#scroll").niceScroll({cursorcolor:"#000"});

  }

);



$(document).ready(function() {

var owl = $("#owl-demo");

owl.owlCarousel({
navigation : true,
singleItem : true,
autoPlay : 3500,
navigation : false,
pagination : false,
transitionStyle : "fade",
navigationText: [
"<i class='fa fa-angle-left'></i>",
"<i class='fa fa-angle-right'></i>"
]
});

});











$(window).scroll(function() {
$('.ani').each(function(){
var imagePos = $(this).offset().top;

var topOfWindow = $(window).scrollTop();
if (imagePos < topOfWindow+400) {
$(this).addClass("fadeIn");
}
});
});








