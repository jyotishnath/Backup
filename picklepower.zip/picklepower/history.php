<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>history</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>History</h1>
				<p>Originally Developed in 2001 with the dual purpose of replenishing electrolytes lost during strenuous exercise and addressing muscle cramps, The Pickle Juice Company has evolved to become one of “the best kept secrets” in the Athletic Trainer and Elite Athlete communities. The formula was tested and revised in the marketplace for the better part of a decade in order to develop the most effective formula possible to address the neurological elements that directly lead to muscle cramping as well as replenishing electrolytes that contribute to hydration. Extra Strength Pickle Juice shots were released to the marketplace in 2012 in order to provide a portable product for the individual endurance athlete as well as a the Athletic Trainer’s kit. Spring of 2015 marked the opening of our state of the art manufacturing facility in Mesquite, TX, introduction of our 100% natural Pickle Juice Sport formula as well as our International expansion plans. Our commitment to improving the performance of athletes is as strong as it ever has been as is evidenced by the increase in elite events that Pickle Juice Sport is endorsing and attending.</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>