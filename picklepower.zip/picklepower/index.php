<?php 
	//Header
	include('header.php'); 
?>

<?php
	//Carousel
	include('carosal.php');

	//Product Carousel
	include('product_carousel.php');

	//News
	include('news.php');
?>

<?php
	//Footer
	include('footer.php');
?>