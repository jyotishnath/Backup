<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Pickle Power</title>
	<!-- Custom Css -->
	<link rel="stylesheet" href="assets/css/custom_css.css">
	<!-- Bootstrap -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- Font-Awesome -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Titillium Web font -->
	<link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
	<link rel="icon" type="image/x-icon" href="assets/img/fav.ico">
	<style type="text/css">
	/*Navigation Custom*/
	@media (max-width: 2000px) {
		.navbar { 
			margin-bottom: 0 !important;
			/*background: #000;*/
		}
	    .navbar-header {
	        float: none;
	    }
	    .navbar-left,.navbar-right {
	        float: none !important;
	    }
	    .navbar-toggle {
	        display: block;
		    position: absolute;
		    right: 15%;
		    top: 36%;
		    padding: 33px;
	    }
	    .navbar-collapse {
	        border-top: 1px solid transparent;
	        box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
	    }
	    .navbar-fixed-top {
	        top: 0;
	        border-width: 0 0 1px;
	    }
	    .navbar-collapse.collapse {
	        display: none!important;
	    }
	    .navbar-nav {
	        float: none!important;
	        margin-top: 7.5px;
	    }
	    .navbar-nav>li {
	        float: none;
	    }
	    .navbar-nav>li>a {
	        padding-top: 10px;
		    padding-bottom: 17px;
		    color: #fff;
		    font-size: 2em;
	    }
	    .collapse.in{
	        display:block !important;
	        position: absolute;
	        background: rgba(0, 0, 0, 0.69);
	    }
	}
	</style>
</head>
<body>
<div class="body-bg">
<!-- Navigation Start-->
<nav class="navbar navbar-fixed-top" >
  <div class="navbar-header">
  	<a href="index.php"><img src="assets/img/logo.png" height="209" width="238" alt="Pickle Power"></a>
  	<div class="shoping-cart">
  		<ul>
  			<li><a href="#"><i class="fa fa-lock" aria-hidden="true"></i> My Account</a></li>
  			<li><a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i> 0 items - $0.00</a></li>
  			<li><a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i> Checkout</a></li>
  			<li><a href="#"><i class="fa fa-sign-in" aria-hidden="true"></i> Signin</a></li>
  		</ul>
  	</div>
    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <div class="navbar-collapse collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li class="dropdown-submenu">
      	<a class="test" tabindex="1" href="">About<span class="caret"></span></a>
      	<ul class="dropdown-menu">
      		<li><a tabindex="-1" href="about.php">About Us</a></li>
      		<li><a tabindex="-1" href="history.php">History</a></li>
      		<li><a tabindex="-1" href="media-press.php">Media / Press</a></li>
      		<li><a tabindex="-1" href="mission-statement.php">Mission Statement</a></li>
      		<li><a tabindex="-1" href="faq.php">Faq</a></li>
      	</ul>
      </li>
      <li class="dropdown-submenu">
		<a class="test" tabindex="-1" href="">The Product<span class="caret"></span></a>
		<ul class="dropdown-menu">
      		<li><a tabindex="-1" href="ingredients.php">Ingredients</a></li>
      		<li><a tabindex="-1" href="scientific-study.php">Scientific Study</a></li>
      		<li><a tabindex="-1" href="storage-recommendations.php">Storage Recommendations</a></li>
      	</ul>
      </li>
    </ul>
  </div>
</nav>
<!-- Navigation End -->