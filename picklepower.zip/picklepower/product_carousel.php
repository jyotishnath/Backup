<div class="container">
  <div class="row">
    <h2 class="sec_head">Product Focus</h2>
    <span class="shadow-head"><img src="assets/img/shadow.png" height="20" alt=""></span>
  </div>
</div>
<div class="carousel-reviews broun-block">
  <div class="container">
    <div class="row">
      <div id="carousel-reviews" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="item active"> 
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6"> <span class="thumbnail"> <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
              <h4>12 Pack of 8oz Pickle Juice</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right">BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6"> <span class="thumbnail"> <img src="assets/products/12x16oz2-500x400.png" height="400" width="500" alt="...">
              <h4>16 oz, 12 Pack of Pickle Juicel</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>12 X 16 oz Bottles of 100% natural Pickle Juice Sport, 16 oz, 12 Pack of Pickle Juice Sport bottles – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$24.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6"> <span class="thumbnail"> <img src="assets/products/2oz.png" height="400" width="500" alt="...">
              <h4>12 pack Pickle Juice</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>12 X 2.5 oz Extra Strength Pickle Juice Shots, 12 pack of 2.5oz Extra Strength Pickle Juice Shots – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6"> <span class="thumbnail"> <img src="assets/products/48pack.png" height="400" width="500" alt="...">
              <h4>48 pack case Pickle Juice</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>48 X 2.5 oz Pickle Juice Shots, 48 pack case of 2.5 oz Extra Strength Pickle Juice Shots – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$96.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
          </div>
          <div class="item">
            <div class="col-md-3 col-sm-6"> <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <div class="col-md-3 col-sm-6 hidden-xs"> <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <div class="col-md-3 col-sm-6 hidden-sm hidden-xs"> <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
            <div class="col-md-3 col-sm-6 hidden-sm hidden-xs"> <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span> </div>
          </div>
          <div class="item">
            <div class="col-md-3 col-sm-6">
              <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span>
            </div>
            <div class="col-md-3 col-sm-6 hidden-xs">
              <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span>
            </div>
            <div class="col-md-3 col-sm-6 hidden-sm hidden-xs">
              <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span>
            </div>
            <div class="col-md-3 col-sm-6 hidden-sm hidden-xs">
              <span class="thumbnail"> <img src="http://placehold.it/500x400" alt="...">
              <h4>Product Tittle</h4>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="price">$29,90</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <button class="btn btn-success right"> BUY ITEM</button>
                </div>
              </div>
              </span>
            </div>
          </div>
        </div>
        <div class="carousel-arrow">
          <a class="left-carousel-control" href="#carousel-reviews" role="button" data-slide="prev"> <span class="left-arrow glyphicon glyphicon-chevron-left"></span> </a> <a class="right-carousel-control" href="#carousel-reviews" role="button" data-slide="next"> <span class="right-arrow glyphicon glyphicon-chevron-right"></span> </a>
        </div>
      </div><!-- carousel slide -->
    </div>
  </div>
</div>